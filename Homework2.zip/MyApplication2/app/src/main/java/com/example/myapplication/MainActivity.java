package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText inputTempText;
    Button convertButton;
    TextView convertedText;

    // Define a constant key for the saved instance state
    private static final String KEY_RESULT = "resultText";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect to views
        inputTempText = findViewById(R.id.inputTempEditText);
        convertButton = findViewById(R.id.convertButton);
        convertedText = findViewById(R.id.convertedTempTextView);

        // Register and handle event click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strFh = convertToFh(inputTempText.getText().toString());
                convertedText.setText(strFh);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
            }
        });

        // Restore the saved instance state if available
        if (savedInstanceState != null) {
            String savedResultText = savedInstanceState.getString(KEY_RESULT);
            convertedText.setText(savedResultText);
        }
    }

    private String convertToFh(String pCelsius) {
        try {
            double c = Double.parseDouble(pCelsius);
            double f = c * (9.0 / 5.0) + 32.0;
            return String.format("%3.2f", f);
        } catch (NumberFormatException nfe) {
            return "Err";
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the convertedText text to the bundle
        outState.putString(KEY_RESULT, convertedText.getText().toString());
    }
}
