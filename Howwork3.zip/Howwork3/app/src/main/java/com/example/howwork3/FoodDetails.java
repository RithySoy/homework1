package com.example.howwork3;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FoodDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.furit);
        Bundle dataBundle = getIntent().getExtras();
        String foodName = dataBundle.getString("name");
        int img = dataBundle.getInt("image");

        TextView foodTextview = findViewById(R.id.textView3);
        ImageView image = findViewById(R.id.imageView2);

        foodTextview.setText(foodName);
        image.setImageResource(img);



    }
}


