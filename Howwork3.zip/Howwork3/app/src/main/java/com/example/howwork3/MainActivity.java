package com.example.howwork3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private void showFoodView(String foodName,int drawbleImage){
        Bundle dataBundle = new Bundle();
        dataBundle.putString("name",foodName);
        dataBundle.putInt("image",drawbleImage);
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(),FoodDetails.class);
        intent.putExtras(dataBundle);
        startActivity(intent);
    }
    public void phoneBtn(View view){
        Intent dial = new Intent(Intent.ACTION_DIAL);
        startActivity(dial);
    }
    public void browserBtn(View view){
        String url = "https://www.limkokwing.com/";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    public void fruitBtnClickHandler(View v){
    showFoodView("Fruit" ,R.drawable.b);
    }
    public void VegetableBtnClickHandler(View v){
    showFoodView("Vetetable",R.drawable.abc);
    }
    public void FoodBtnClickHandler(View v){
     showFoodView("Food",R.drawable.d);
    }
}
